//: Playground - noun: a place where people can play

import UIKit

// function to convert celsius temperatures to fehrenheit
func  convertToF(F: Double) -> Double{
    
    var c: Double
    
    c = (5 * (F - 32))/9
    
    return (c)
}

func convertToC(C: Double) -> Double{
    
    var f: Double
    
    f = ((9 * C)/5) + 32
    
    return (f)
}

let celsius: [Double] = [0, 6, 12, 18, 24, 30, 36, 42, 48]

for (index, value) in celsius.enumerated()
{
    print(convertToF(F: value))
}

let fehrenheit: [Double] = [-17.77, -14.44, -11.11, -7.77, -4.44, -1.11, 2.22, 5.55, 8.88]

for index in 1...6
{
    print()
}

for (index, value) in fehrenheit.enumerated()
{
    print(convertToC(C: value))
}